from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./data/libraverify.db"
    secret_key: str = "change-me-in-production-please-use-long-random-string"
    admin_username: str = "admin"
    admin_password: str = "admin123"
    library_email: str = "library@example.edu"
    openalex_api_key: str = ""
    semantic_scholar_api_key: str = ""
    ncbi_api_key: str = ""
    allowed_origins: str = "http://localhost:8000,http://127.0.0.1:8000"

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()

# Ensure data directory exists for SQLite
if settings.database_url.startswith("sqlite"):
    os.makedirs("data", exist_ok=True)

engine = create_async_engine(
    settings.database_url,
    echo=False,
    pool_pre_ping=True,
)
AsyncSessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

async def init_db():
    from backend.models import AuditLog, LibraryConfig, VerificationJob, OpenSource
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
