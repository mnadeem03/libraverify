from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON
from sqlalchemy.sql import func
from backend.database import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    action = Column(String(100), nullable=False)
    query = Column(Text)
    result_summary = Column(Text)
    source = Column(String(50))
    user = Column(String(100), default="anonymous")
    ip_address = Column(String(50))
    success = Column(Boolean, default=True)
    details = Column(JSON)

class LibraryConfig(Base):
    __tablename__ = "library_config"
    id = Column(Integer, primary_key=True)
    key = Column(String(120), unique=True, nullable=False, index=True)
    value = Column(Text)
    category = Column(String(60), default="general")
    label = Column(String(200))
    description = Column(Text)
    is_secret = Column(Boolean, default=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class OpenSource(Base):
    """Editable registry of open-source verification databases and web endpoints."""
    __tablename__ = "open_sources"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    slug = Column(String(80), unique=True, nullable=False, index=True)
    category = Column(String(60), default="scholarly")  # scholarly, books, web, integrity, ils, custom
    base_url = Column(String(500))
    docs_url = Column(String(500))
    api_key_config_key = Column(String(120))  # optional link to library_config key
    enabled = Column(Boolean, default=True)
    is_builtin = Column(Boolean, default=False)
    description = Column(Text)
    notes = Column(Text)
    sort_order = Column(Integer, default=100)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class VerificationJob(Base):
    __tablename__ = "verification_jobs"
    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(30), default="pending")
    input_type = Column(String(30))
    total_items = Column(Integer, default=0)
    processed = Column(Integer, default=0)
    results = Column(JSON)
    report_path = Column(String(255))
    user = Column(String(100))
