import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://api.semanticscholar.org/graph/v1"

def _headers():
    h = {"User-Agent": f"LibraVerifyPro/1.0 (mailto:{settings.library_email})"}
    if settings.semantic_scholar_api_key:
        h["x-api-key"] = settings.semantic_scholar_api_key
    return h

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_doi(doi: str) -> dict:
    clean = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
    url = f"{BASE}/paper/DOI:{clean}"
    params = {"fields": "title,authors,year,venue,citationCount,externalIds,isOpenAccess,openAccessPdf,url"}
    async with httpx.AsyncClient(timeout=20.0, headers=_headers()) as client:
        r = await client.get(url, params=params)
        if r.status_code == 404:
            return {"found": False, "doi": clean, "source": "semantic_scholar"}
        r.raise_for_status()
        return _normalize(r.json())

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def search(query: str, limit: int = 5) -> list:
    url = f"{BASE}/paper/search"
    params = {
        "query": query,
        "limit": limit,
        "fields": "title,authors,year,venue,citationCount,externalIds,isOpenAccess,url",
    }
    async with httpx.AsyncClient(timeout=25.0, headers=_headers()) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        data = r.json()
        return [_normalize(p) for p in data.get("data", [])]

def _normalize(item: dict) -> dict:
    authors = [a.get("name") for a in item.get("authors", []) if a.get("name")]
    ext = item.get("externalIds") or {}
    return {
        "found": True,
        "source": "semantic_scholar",
        "doi": ext.get("DOI"),
        "title": item.get("title"),
        "authors": authors,
        "year": item.get("year"),
        "container_title": item.get("venue"),
        "cited_by": item.get("citationCount", 0),
        "is_oa": item.get("isOpenAccess"),
        "oa_url": (item.get("openAccessPdf") or {}).get("url"),
        "url": item.get("url") or f"https://www.semanticscholar.org/paper/{item.get('paperId')}",
    }
