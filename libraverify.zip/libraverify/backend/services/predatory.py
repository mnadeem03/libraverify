"""
Lightweight heuristic flags for potentially predatory or low-quality venues.
This is NOT a definitive blacklist. Always combine with librarian judgment,
DOAJ membership, ISSN Portal, and institutional guidelines.
"""
from typing import Optional

# Very small illustrative set of high-signal patterns / known problematic strings.
# Libraries should maintain their own curated lists.
SUSPICIOUS_PUBLISHER_KEYWORDS = [
    "omics", "scientific research publishing", "scirp", "hindawi" ,  # note: Hindawi is now Wiley; kept only as historical example
    "academic journals", "international journal of advanced",
    "worldwide journals", "global journals", "iosr journals",
]

SUSPICIOUS_TITLE_PATTERNS = [
    "international journal of advanced research",
    "world journal of",
    "global journal of",
    "american scientific research",
]

def assess_venue(
    container_title: Optional[str] = None,
    publisher: Optional[str] = None,
    issn_list: Optional[list] = None,
    is_in_doaj_hint: Optional[bool] = None,
) -> dict:
    """
    Return heuristic risk flags. Never auto-reject; surface for human review.
    """
    flags = []
    risk = "low"
    notes = []

    title = (container_title or "").lower()
    pub = (publisher or "").lower()

    for kw in SUSPICIOUS_PUBLISHER_KEYWORDS:
        if kw in pub:
            flags.append(f"Publisher name contains pattern often associated with questionable outlets: '{kw}'")
            risk = "medium"

    for pat in SUSPICIOUS_TITLE_PATTERNS:
        if pat in title:
            flags.append(f"Journal title matches a common predatory-style pattern: '{pat}'")
            risk = "medium"

    if not issn_list:
        flags.append("No ISSN found in metadata – verify journal registration via ISSN Portal")
        if risk == "low":
            risk = "medium"

    if is_in_doaj_hint is False:
        notes.append("Not confirmed in DOAJ (Directory of Open Access Journals)")

    if not flags:
        notes.append("No strong predatory heuristics triggered. Still verify with DOAJ / Think.Check.Submit / institutional lists.")

    return {
        "source": "predatory_heuristics",
        "risk": risk,
        "flags": flags,
        "notes": notes,
        "resources": [
            {"name": "Think. Check. Submit.", "url": "https://thinkchecksubmit.org"},
            {"name": "DOAJ", "url": "https://doaj.org"},
            {"name": "ISSN Portal", "url": "https://portal.issn.org"},
            {"name": "Cabells (subscribed)", "url": "https://www2.cabells.com"},
        ],
    }
