"""Builtin open-source registry seed + helpers."""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from backend.models import OpenSource

BUILTIN = [
    {"name": "Crossref", "slug": "crossref", "category": "scholarly", "base_url": "https://api.crossref.org", "docs_url": "https://www.crossref.org/documentation/retrieve-metadata/rest-api/", "enabled": True, "is_builtin": True, "description": "Official DOI registration agency metadata", "sort_order": 10},
    {"name": "OpenAlex", "slug": "openalex", "category": "scholarly", "base_url": "https://api.openalex.org", "docs_url": "https://docs.openalex.org", "enabled": True, "is_builtin": True, "description": "Open scholarly knowledge graph", "sort_order": 20},
    {"name": "Unpaywall", "slug": "unpaywall", "category": "scholarly", "base_url": "https://api.unpaywall.org", "docs_url": "https://unpaywall.org/products/api", "enabled": True, "is_builtin": True, "description": "Legal open-access status for DOIs", "sort_order": 30},
    {"name": "Semantic Scholar", "slug": "semantic_scholar", "category": "scholarly", "base_url": "https://api.semanticscholar.org", "docs_url": "https://www.semanticscholar.org/product/api", "enabled": True, "is_builtin": True, "description": "AI-powered academic graph", "sort_order": 40},
    {"name": "PubMed / NCBI", "slug": "pubmed", "category": "scholarly", "base_url": "https://eutils.ncbi.nlm.nih.gov", "docs_url": "https://www.ncbi.nlm.nih.gov/home/develop/api/", "enabled": True, "is_builtin": True, "description": "Biomedical literature", "sort_order": 50},
    {"name": "Open Library", "slug": "openlibrary", "category": "books", "base_url": "https://openlibrary.org", "docs_url": "https://openlibrary.org/developers/api", "enabled": True, "is_builtin": True, "description": "Book and edition metadata", "sort_order": 60},
    {"name": "Wikipedia", "slug": "wikipedia", "category": "web", "base_url": "https://en.wikipedia.org/api/rest_v1", "docs_url": "https://www.mediawiki.org/wiki/API:Main_page", "enabled": True, "is_builtin": True, "description": "Encyclopaedic context for claims (tertiary source)", "sort_order": 70},
    {"name": "Retraction Watch (link-out)", "slug": "retraction_watch", "category": "integrity", "base_url": "https://retractionwatch.com", "docs_url": "https://retractionwatch.com", "enabled": True, "is_builtin": True, "description": "Human-curated retraction reporting; used with Crossref signals", "sort_order": 80},
    {"name": "DOAJ", "slug": "doaj", "category": "integrity", "base_url": "https://doaj.org", "docs_url": "https://doaj.org", "enabled": True, "is_builtin": True, "description": "Directory of Open Access Journals", "sort_order": 90},
    {"name": "ISSN Portal", "slug": "issn", "category": "integrity", "base_url": "https://portal.issn.org", "docs_url": "https://portal.issn.org", "enabled": True, "is_builtin": True, "description": "Official ISSN registry", "sort_order": 100},
    {"name": "DataCite", "slug": "datacite", "category": "scholarly", "base_url": "https://api.datacite.org", "docs_url": "https://support.datacite.org/docs/api", "enabled": False, "is_builtin": True, "description": "DOIs for datasets and research outputs", "sort_order": 110},
    {"name": "ORCID", "slug": "orcid", "category": "scholarly", "base_url": "https://orcid.org", "docs_url": "https://info.orcid.org/documentation/", "enabled": False, "is_builtin": True, "description": "Researcher identifiers", "sort_order": 120},
    {"name": "arXiv", "slug": "arxiv", "category": "scholarly", "base_url": "https://arxiv.org", "docs_url": "https://arxiv.org/help/api", "enabled": False, "is_builtin": True, "description": "Preprint repository (physics, CS, maths, etc.)", "sort_order": 130},
    {"name": "Think. Check. Submit.", "slug": "thinkchecksubmit", "category": "integrity", "base_url": "https://thinkchecksubmit.org", "docs_url": "https://thinkchecksubmit.org", "enabled": True, "is_builtin": True, "description": "Guidance for identifying trusted journals", "sort_order": 140},
]

async def ensure_builtin_sources(db: AsyncSession):
    for item in BUILTIN:
        existing = await db.scalar(select(OpenSource).where(OpenSource.slug == item["slug"]))
        if not existing:
            db.add(OpenSource(**item))
    await db.commit()
