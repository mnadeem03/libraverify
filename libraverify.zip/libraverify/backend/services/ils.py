"""
ILS / Repository integration helpers for Koha, FOLIO, and DSpace.
These use configurable base URLs and optional API keys stored in LibraryConfig.
They perform read-only search when endpoints are configured.
"""
import httpx
from typing import Optional

async def search_koha(base_url: str, query: str, api_key: Optional[str] = None) -> dict:
    """
    Koha SRU or REST search (simplified).
    Common pattern: {base}/cgi-bin/koha/opac-search.pl or REST /api/v1/...
    """
    if not base_url:
        return {"configured": False, "results": [], "message": "Koha base URL not configured"}
    base = base_url.rstrip("/")
    # Prefer public OPAC search page as fallback discovery link
    opac = f"{base}/cgi-bin/koha/opac-search.pl?q={httpx.QueryParams({'q': query})['q']}"
    results = []
    # Try a common REST path if available (many installs differ)
    try:
        headers = {"Accept": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
            for path in (f"/api/v1/biblios?q={query}", f"/api/v1/patrons?q={query}"):
                try:
                    r = await client.get(base + path, headers=headers)
                    if r.status_code == 200:
                        data = r.json()
                        results.append({"path": path, "data": data if isinstance(data, list) else data})
                        break
                except Exception:
                    continue
    except Exception as e:
        return {"configured": True, "results": [], "opac_search": opac, "error": str(e)}
    return {"configured": True, "results": results, "opac_search": opac, "source": "koha"}


async def search_folio(okapi_url: str, tenant: str, query: str, token: Optional[str] = None) -> dict:
    if not okapi_url:
        return {"configured": False, "results": [], "message": "FOLIO Okapi URL not configured"}
    base = okapi_url.rstrip("/")
    headers = {"X-Okapi-Tenant": tenant or "diku", "Accept": "application/json"}
    if token:
        headers["X-Okapi-Token"] = token
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(
                f"{base}/inventory/instances",
                params={"query": f'title="{query}"', "limit": 5},
                headers=headers,
            )
            if r.status_code in (401, 403):
                return {"configured": True, "results": [], "message": "FOLIO auth required – set token in Admin", "status_code": r.status_code}
            r.raise_for_status()
            data = r.json()
            return {"configured": True, "source": "folio", "total": data.get("totalRecords"), "results": data.get("instances", [])[:5]}
    except Exception as e:
        return {"configured": True, "results": [], "error": str(e), "source": "folio"}


async def search_dspace(base_url: str, query: str, api_key: Optional[str] = None) -> dict:
    if not base_url:
        return {"configured": False, "results": [], "message": "DSpace base URL not configured"}
    base = base_url.rstrip("/")
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    # DSpace 7 REST
    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
            r = await client.get(
                f"{base}/server/api/discover/search/objects",
                params={"query": query, "size": 5},
                headers=headers,
            )
            if r.status_code == 404:
                # older style
                r = await client.get(f"{base}/rest/search", params={"query": query}, headers=headers)
            if r.status_code >= 400:
                return {"configured": True, "results": [], "status_code": r.status_code, "discovery_url": f"{base}/discover?query={query}"}
            data = r.json()
            return {"configured": True, "source": "dspace", "results": data, "discovery_url": f"{base}/discover?query={query}"}
    except Exception as e:
        return {"configured": True, "results": [], "error": str(e), "discovery_url": f"{base}/discover?query={query}"}
