import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://api.unpaywall.org/v2"

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_doi(doi: str) -> dict:
    """Return open-access status and best free PDF/HTML link."""
    clean = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
    url = f"{BASE}/{clean}"
    params = {"email": settings.library_email}
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(url, params=params)
        if r.status_code == 404:
            return {"found": False, "doi": clean, "source": "unpaywall", "is_oa": False}
        r.raise_for_status()
        data = r.json()
        best = data.get("best_oa_location") or {}
        return {
            "found": True,
            "source": "unpaywall",
            "doi": data.get("doi"),
            "title": data.get("title"),
            "is_oa": data.get("is_oa", False),
            "oa_status": data.get("oa_status"),
            "best_oa_url": best.get("url_for_pdf") or best.get("url"),
            "host_type": best.get("host_type"),
            "license": best.get("license"),
            "version": best.get("version"),
        }
