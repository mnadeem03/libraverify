"""
Central verification orchestrator.
Queries multiple open sources in parallel and produces a unified report
including retraction signals and predatory heuristics.
"""
import asyncio
from typing import Optional
from backend.services import crossref, openalex, unpaywall
from backend.services import semantic_scholar, pubmed, retraction, predatory

async def verify_single(
    doi: Optional[str] = None,
    title: Optional[str] = None,
    issn: Optional[str] = None,
) -> dict:
    report = {
        "input": {"doi": doi, "title": title, "issn": issn},
        "status": "unknown",
        "confidence": "low",
        "sources": {},
        "flags": [],
        "recommendations": [],
        "retraction": None,
        "predatory": None,
        "open_access": None,
        "primary": None,
    }

    tasks = []
    if doi:
        tasks.append(("crossref", crossref.lookup_doi(doi)))
        tasks.append(("openalex", openalex.lookup_doi(doi)))
        tasks.append(("unpaywall", unpaywall.lookup_doi(doi)))
        tasks.append(("semantic_scholar", semantic_scholar.lookup_doi(doi)))
        tasks.append(("pubmed", pubmed.lookup_doi(doi)))
        tasks.append(("retraction", retraction.check_retraction(doi)))
    if title and not doi:
        tasks.append(("crossref_search", crossref.search_bibliographic(title, rows=5)))
        tasks.append(("openalex_search", openalex.search(title, per_page=5)))
        tasks.append(("semantic_scholar_search", semantic_scholar.search(title, limit=5)))
        tasks.append(("pubmed_search", pubmed.search(title, retmax=5)))
    if issn:
        tasks.append(("crossref_issn", crossref.lookup_issn(issn)))

    if not tasks:
        report["status"] = "error"
        report["flags"].append("No DOI, title or ISSN provided")
        return report

    results = await asyncio.gather(*[t[1] for t in tasks], return_exceptions=True)

    for (name, _), result in zip(tasks, results):
        if isinstance(result, Exception):
            report["sources"][name] = {"error": str(result)}
            continue
        report["sources"][name] = result

    # Extract primary records
    cr = report["sources"].get("crossref")
    oa = report["sources"].get("openalex")
    ss = report["sources"].get("semantic_scholar")
    pm = report["sources"].get("pubmed")

    # Handle search result lists
    for key in ("crossref_search", "openalex_search", "semantic_scholar_search", "pubmed_search"):
        val = report["sources"].get(key)
        if isinstance(val, list) and val:
            if key.startswith("crossref") and not cr:
                cr = val[0]
            elif key.startswith("openalex") and not oa:
                oa = val[0]
            elif key.startswith("semantic") and not ss:
                ss = val[0]
            elif key.startswith("pubmed") and not pm:
                pm = val[0]

    found_cr = isinstance(cr, dict) and cr.get("found")
    found_oa = isinstance(oa, dict) and oa.get("found")
    found_ss = isinstance(ss, dict) and ss.get("found")
    found_pm = isinstance(pm, dict) and pm.get("found")

    sources_hit = sum([found_cr, found_oa, found_ss, found_pm])

    if sources_hit >= 2:
        report["status"] = "verified"
        report["confidence"] = "high"
    elif sources_hit == 1:
        report["status"] = "partial"
        report["confidence"] = "medium"
        report["flags"].append("Found in only one major index – double-check details")
    else:
        report["status"] = "not_found"
        report["confidence"] = "low"
        report["flags"].append("No matching record in major indexes – possible fabricated, very new, or obscure citation")

    report["primary"] = next((x for x in (cr, oa, ss, pm) if isinstance(x, dict) and x.get("found")), None)

    # Open access
    up = report["sources"].get("unpaywall")
    if isinstance(up, dict) and up.get("is_oa"):
        report["open_access"] = {
            "is_oa": True,
            "status": up.get("oa_status"),
            "url": up.get("best_oa_url"),
            "license": up.get("license"),
        }
        report["recommendations"].append("Legal open-access version available via Unpaywall")
    elif isinstance(up, dict):
        report["open_access"] = {"is_oa": False}

    # Retraction
    ret = report["sources"].get("retraction")
    if isinstance(ret, dict):
        report["retraction"] = ret
        if ret.get("is_retracted"):
            report["flags"].append("⚠️ RETRACTION SIGNAL detected via Crossref – verify on Retraction Watch")
            report["status"] = "retracted"
            report["confidence"] = "high"
            report["recommendations"].append("Check Retraction Watch and do not recommend this work as authoritative")
        elif ret.get("is_corrected"):
            report["flags"].append("Correction / erratum exists – consult the updated version")

    # Predatory heuristics
    primary = report["primary"] or {}
    pred = predatory.assess_venue(
        container_title=primary.get("container_title"),
        publisher=primary.get("publisher") if isinstance(primary, dict) else None,
        issn_list=primary.get("issn") if isinstance(primary, dict) else None,
    )
    report["predatory"] = pred
    if pred.get("risk") in ("medium", "high"):
        report["flags"].extend(pred.get("flags", []))
        report["recommendations"].append("Review journal quality with Think.Check.Submit / DOAJ / institutional lists")

    # Title mismatch
    if doi and found_cr and title and isinstance(cr, dict):
        cr_title = (cr.get("title") or "").lower()
        if title.lower()[:40] not in cr_title and cr_title[:40] not in title.lower():
            report["flags"].append("Title supplied by user does not closely match Crossref title – possible metadata error or hallucination")

    if report["status"] == "not_found":
        report["recommendations"].append("Ask the user for the original PDF or a more precise citation")
        report["recommendations"].append("Search Google Scholar / Web of Science (if subscribed) as a secondary check")

    return report


async def verify_batch(items: list[dict]) -> list[dict]:
    results = []
    for item in items:
        r = await verify_single(
            doi=item.get("doi"),
            title=item.get("title"),
            issn=item.get("issn"),
        )
        results.append(r)
        await asyncio.sleep(0.35)  # polite rate limiting
    return results
