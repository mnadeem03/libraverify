import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://api.openalex.org"

def _headers():
    h = {"User-Agent": f"LibraVerifyPro/1.0 (mailto:{settings.library_email})"}
    return h

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_doi(doi: str) -> dict:
    clean = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
    url = f"{BASE}/works/https://doi.org/{clean}"
    params = {}
    if settings.openalex_api_key:
        params["api_key"] = settings.openalex_api_key
    async with httpx.AsyncClient(timeout=20.0, headers=_headers()) as client:
        r = await client.get(url, params=params)
        if r.status_code == 404:
            return {"found": False, "doi": clean, "source": "openalex"}
        r.raise_for_status()
        return _normalize(r.json())

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def search(query: str, per_page: int = 5) -> list:
    url = f"{BASE}/works"
    params = {"search": query, "per_page": per_page}
    if settings.openalex_api_key:
        params["api_key"] = settings.openalex_api_key
    async with httpx.AsyncClient(timeout=25.0, headers=_headers()) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        results = r.json().get("results", [])
        return [_normalize(item) for item in results]

def _normalize(item: dict) -> dict:
    authors = [a.get("author", {}).get("display_name") for a in item.get("authorships", []) if a.get("author")]
    source = item.get("primary_location", {}).get("source", {}) or {}
    return {
        "found": True,
        "source": "openalex",
        "id": item.get("id"),
        "doi": item.get("doi"),
        "title": item.get("display_name") or item.get("title"),
        "authors": authors,
        "year": item.get("publication_year"),
        "container_title": source.get("display_name"),
        "type": item.get("type"),
        "cited_by": item.get("cited_by_count", 0),
        "is_oa": item.get("open_access", {}).get("is_oa"),
        "oa_url": item.get("open_access", {}).get("oa_url"),
        "url": item.get("id"),
    }
