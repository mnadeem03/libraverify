"""
General fact / hallucination / misinformation assist for librarian queries.
This does NOT claim absolute truth. It structures claims, cross-checks against
scholarly indexes when possible, and returns a transparent assessment for human judgment.
"""
import re
from typing import Optional
from backend.services import crossref, openalex, semantic_scholar, pubmed, openlibrary, wikipedia

CLAIM_SPLIT = re.compile(r"(?<=[.!?])\s+")

async def analyze_claim_or_query(text: str, mode: str = "auto") -> dict:
    """
    mode: auto | citation | fact | book
    """
    text = (text or "").strip()
    if not text:
        return {"status": "error", "flags": ["Empty query"]}

    # Detect likely citation / DOI / ISBN
    doi_match = re.search(r"10\.\d{4,9}/[-._;()/:A-Z0-9]+", text, re.I)
    isbn_match = re.search(r"(?:ISBN[- ]?)?(97[89][-\d]{10,16}|\d{9}[\dXx])", text, re.I)

    report = {
        "input": text[:2000],
        "mode": mode,
        "status": "reviewed",
        "confidence": "low",
        "claims": [],
        "scholarly_matches": [],
        "book_matches": [],
        "flags": [],
        "misinfo_signals": [],
        "recommendations": [],
        "summary": "",
    }

    if mode == "auto":
        if doi_match or (len(text) < 400 and re.search(r"\b(19|20)\d{2}\b", text) and "," in text):
            mode = "citation"
        elif isbn_match or re.search(r"\b(book|edition|publisher|isbn)\b", text, re.I):
            mode = "book"
        else:
            mode = "fact"
        report["mode"] = mode

    # Extract simple claim sentences
    sentences = [s.strip() for s in CLAIM_SPLIT.split(text) if len(s.strip()) > 20][:8]
    if not sentences:
        sentences = [text[:300]]
    report["claims"] = [{"id": i + 1, "text": s} for i, s in enumerate(sentences)]

    # Scholarly cross-check on first claim / full text
    query = sentences[0] if sentences else text
    try:
        if mode in ("citation", "fact", "auto"):
            cr = await crossref.search_bibliographic(query[:200], rows=3)
            oa = await openalex.search(query[:200], per_page=3)
            ss = await semantic_scholar.search(query[:120], limit=3)
            report["scholarly_matches"] = {
                "crossref": cr,
                "openalex": oa,
                "semantic_scholar": ss,
            }
            hits = sum(1 for src in (cr, oa, ss) if src)
            if hits >= 2:
                report["confidence"] = "medium"
                report["summary"] = "Related scholarly records found in multiple indexes. Review matches carefully."
            elif hits == 1:
                report["confidence"] = "low"
                report["summary"] = "Limited scholarly support found. Treat as needing further verification."
            else:
                report["misinfo_signals"].append("No close matches in major scholarly indexes for this wording")
                report["flags"].append("Possible unsupported claim, hallucination-style citation, or non-scholarly statement")
                report["summary"] = "No strong scholarly matches. High caution recommended."
    except Exception as e:
        report["flags"].append(f"Scholarly search error: {e}")

    # Web / encyclopaedia context (open)
    try:
        wiki = await wikipedia.search_and_summarize(query[:180], limit=3)
        report["web_context"] = wiki
        if wiki.get("found"):
            report["recommendations"].append("Wikipedia context found – treat as tertiary background only, not proof.")
    except Exception as e:
        report["flags"].append(f"Wikipedia context error: {e}")

    # Book path
    if mode == "book" or isbn_match:
        try:
            if isbn_match:
                isbn = re.sub(r"[^0-9Xx]", "", isbn_match.group(0))[-13:]
                book = await openlibrary.lookup_isbn(isbn)
                report["book_matches"] = [book] if book.get("found") else []
            else:
                books = await openlibrary.search_books(query, limit=5)
                report["book_matches"] = books
            if report["book_matches"]:
                report["confidence"] = "medium" if report["confidence"] == "low" else report["confidence"]
                report["summary"] = (report["summary"] + " Book metadata matches found in Open Library.").strip()
            else:
                report["flags"].append("No book match in Open Library for ISBN/title")
        except Exception as e:
            report["flags"].append(f"Book search error: {e}")

    # Lightweight misinfo heuristics (transparent, not definitive)
    lower = text.lower()
    sensational = ["miracle cure", "doctors hate", "secret they don't want", "100% proven", "always true", "never fails"]
    for s in sensational:
        if s in lower:
            report["misinfo_signals"].append(f"Sensational phrasing detected: “{s}”")
    if re.search(r"\b(always|never|everyone knows|proven fact)\b", lower):
        report["misinfo_signals"].append("Absolute language – often a sign of overclaiming")
    if doi_match is None and re.search(r"\bdoi\b|\b10\.\d{4,}", lower):
        report["misinfo_signals"].append("DOI-like text present but could not parse a valid DOI")

    report["recommendations"] = [
        "This tool assists librarians; it does not determine absolute truth.",
        "Cross-check primary sources, official statistics, and institutional subscriptions when stakes are high.",
        "For citations: prefer DOI resolution via Crossref + OpenAlex.",
        "For books: confirm ISBN in Open Library / local catalogue (Koha, FOLIO).",
        "For factual claims: seek independent reputable sources published independently of each other.",
    ]
    if report["misinfo_signals"]:
        report["recommendations"].insert(0, "Misinformation-style signals present – do not endorse without independent verification.")

    return report
