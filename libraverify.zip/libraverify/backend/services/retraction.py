"""
Retraction detection helpers.
- Crossref stores "update-to" relations and assertions for retractions works.
- Retraction Watch Database is the authoritative human-curated source;
  we surface a direct search link and any Crossref retraction signals.
"""
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://api.crossref.org"

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def check_retraction(doi: str) -> dict:
    """
    Inspect Crossref metadata for retraction / correction signals.
    Returns a structured flag that the verifier can surface.
    """
    clean = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
    url = f"{BASE}/works/{clean}"
    params = {"mailto": settings.library_email}
    result = {
        "source": "crossref_retraction_check",
        "doi": clean,
        "is_retracted": False,
        "is_corrected": False,
        "updates": [],
        "retraction_watch_url": f"https://retractionwatch.com/?s={clean}",
        "notes": [],
    }
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(url, params=params)
            if r.status_code == 404:
                result["notes"].append("DOI not found in Crossref")
                return result
            r.raise_for_status()
            msg = r.json()["message"]

            # update-to relations
            for upd in msg.get("update-to", []) or []:
                label = (upd.get("label") or "").lower()
                result["updates"].append({
                    "label": upd.get("label"),
                    "doi": upd.get("DOI"),
                    "type": upd.get("type"),
                })
                if "retract" in label:
                    result["is_retracted"] = True
                if "correct" in label or "errat" in label:
                    result["is_corrected"] = True

            # Also look at relation "is-identical-to" / "has-update" style if present
            for rel_type, rels in (msg.get("relation") or {}).items():
                if "retract" in rel_type.lower():
                    result["is_retracted"] = True
                    result["updates"].append({"relation": rel_type, "targets": rels})

            # Assertion-based free-to-read or other flags are less relevant here
            if result["is_retracted"]:
                result["notes"].append("Crossref indicates this work has a retraction-related update")
            if result["is_corrected"]:
                result["notes"].append("Crossref indicates a correction / erratum exists")

    except Exception as e:
        result["notes"].append(f"Retraction check error: {e}")

    return result
