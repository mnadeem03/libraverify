import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://api.crossref.org"

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_doi(doi: str) -> dict:
    """Resolve a DOI against Crossref. Returns normalized metadata or empty dict."""
    clean = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
    url = f"{BASE}/works/{clean}"
    params = {"mailto": settings.library_email}
    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(url, params=params)
        if r.status_code == 404:
            return {"found": False, "doi": clean, "source": "crossref"}
        r.raise_for_status()
        data = r.json()["message"]
        return _normalize(data)

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def search_bibliographic(query: str, rows: int = 5) -> list:
    """Free-text bibliographic search (title, authors, year...)."""
    url = f"{BASE}/works"
    params = {
        "query.bibliographic": query,
        "rows": rows,
        "mailto": settings.library_email,
    }
    async with httpx.AsyncClient(timeout=25.0) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        items = r.json()["message"]["items"]
        return [_normalize(item) for item in items]

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_issn(issn: str) -> dict:
    """Validate journal by ISSN."""
    clean = issn.replace("-", "").strip()
    url = f"{BASE}/journals/{clean}"
    params = {"mailto": settings.library_email}
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(url, params=params)
        if r.status_code == 404:
            return {"found": False, "issn": issn, "source": "crossref"}
        r.raise_for_status()
        data = r.json()["message"]
        return {
            "found": True,
            "source": "crossref",
            "title": data.get("title"),
            "publisher": data.get("publisher"),
            "issn": data.get("ISSN", []),
            "subjects": data.get("subjects", []),
        }

def _normalize(item: dict) -> dict:
    authors = []
    for a in item.get("author", []) or []:
        name = a.get("family", "")
        if a.get("given"):
            name = f"{a['given']} {name}".strip()
        authors.append(name)

    year = None
    for key in ("published-print", "published-online", "created", "deposited"):
        if key in item and item[key].get("date-parts"):
            year = item[key]["date-parts"][0][0]
            break

    return {
        "found": True,
        "source": "crossref",
        "doi": item.get("DOI"),
        "title": (item.get("title") or [None])[0],
        "authors": authors,
        "container_title": (item.get("container-title") or [None])[0],
        "year": year,
        "type": item.get("type"),
        "publisher": item.get("publisher"),
        "issn": item.get("ISSN", []),
        "cited_by": item.get("is-referenced-by-count", 0),
        "url": f"https://doi.org/{item.get('DOI')}" if item.get("DOI") else None,
        "raw": item,  # keep full record for advanced users
    }
