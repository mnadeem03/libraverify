import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings
from xml.etree import ElementTree as ET

BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

def _params_extra():
    p = {"tool": "LibraVerifyPro", "email": settings.library_email}
    if settings.ncbi_api_key:
        p["api_key"] = settings.ncbi_api_key
    return p

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def search(query: str, retmax: int = 5) -> list:
    """Search PubMed by title / keywords and return basic records."""
    search_url = f"{BASE}/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": retmax,
        "retmode": "json",
        **_params_extra(),
    }
    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(search_url, params=params)
        r.raise_for_status()
        ids = r.json().get("esearchresult", {}).get("idlist", [])
        if not ids:
            return []
        return await _fetch_summaries(ids)

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
async def lookup_doi(doi: str) -> dict:
    clean = doi.replace("https://doi.org/", "").strip()
    results = await search(f"{clean}[doi]", retmax=1)
    if results:
        return results[0]
    return {"found": False, "doi": clean, "source": "pubmed"}

async def _fetch_summaries(pmids: list) -> list:
    url = f"{BASE}/esummary.fcgi"
    params = {
        "db": "pubmed",
        "id": ",".join(pmids),
        "retmode": "json",
        **_params_extra(),
    }
    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        result = r.json().get("result", {})
        out = []
        for pmid in pmids:
            item = result.get(pmid)
            if not item:
                continue
            authors = [a.get("name") for a in item.get("authors", []) if a.get("name")]
            out.append({
                "found": True,
                "source": "pubmed",
                "pmid": pmid,
                "doi": next((id["value"] for id in item.get("articleids", []) if id.get("idtype") == "doi"), None),
                "title": item.get("title"),
                "authors": authors,
                "year": (item.get("pubdate") or "")[:4] or None,
                "container_title": item.get("fulljournalname") or item.get("source"),
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            })
        return out
