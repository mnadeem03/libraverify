"""Open Library – free book & edition metadata."""
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from backend.database import settings

BASE = "https://openlibrary.org"

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6))
async def search_books(query: str, limit: int = 8) -> list:
    url = f"{BASE}/search.json"
    params = {"q": query, "limit": limit}
    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        docs = r.json().get("docs", [])
        return [_normalize(d) for d in docs]

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6))
async def lookup_isbn(isbn: str) -> dict:
    clean = isbn.replace("-", "").strip()
    url = f"{BASE}/isbn/{clean}.json"
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(url)
        if r.status_code == 404:
            return {"found": False, "isbn": clean, "source": "openlibrary"}
        r.raise_for_status()
        data = r.json()
        return {
            "found": True,
            "source": "openlibrary",
            "isbn": clean,
            "title": data.get("title"),
            "authors": [a.get("key") for a in data.get("authors", [])],
            "publishers": data.get("publishers", []),
            "publish_date": data.get("publish_date"),
            "number_of_pages": data.get("number_of_pages"),
            "url": f"https://openlibrary.org/isbn/{clean}",
        }

def _normalize(doc: dict) -> dict:
    return {
        "found": True,
        "source": "openlibrary",
        "title": doc.get("title"),
        "authors": doc.get("author_name") or [],
        "year": (doc.get("first_publish_year") or None),
        "isbn": (doc.get("isbn") or [None])[0] if doc.get("isbn") else None,
        "publisher": (doc.get("publisher") or [None])[0] if doc.get("publisher") else None,
        "edition_count": doc.get("edition_count"),
        "url": f"https://openlibrary.org{doc.get('key')}" if doc.get("key") else None,
        "cover": f"https://covers.openlibrary.org/b/id/{doc['cover_i']}-M.jpg" if doc.get("cover_i") else None,
    }
