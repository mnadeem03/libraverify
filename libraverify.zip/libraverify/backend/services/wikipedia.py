"""Wikipedia & Wikidata – open web knowledge for claim context (not definitive fact-check)."""
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from urllib.parse import quote

WIKI_API = "https://en.wikipedia.org/api/rest_v1"
WIKI_SEARCH = "https://en.wikipedia.org/w/api.php"

@retry(stop=stop_after_attempt(2), wait=wait_exponential(multiplier=1, min=1, max=4))
async def search_and_summarize(query: str, limit: int = 3) -> dict:
    """
    Search Wikipedia and return short summaries for librarian context.
    Transparent: encyclopaedia context only, not peer-reviewed proof.
    """
    q = (query or "").strip()[:200]
    if not q:
        return {"found": False, "source": "wikipedia", "results": []}

    results = []
    async with httpx.AsyncClient(timeout=15.0, headers={"User-Agent": "LibraVerify/1.0 (library-verification; mailto:library@example.edu)"}) as client:
        # Search
        r = await client.get(WIKI_SEARCH, params={
            "action": "query", "list": "search", "srsearch": q,
            "srlimit": limit, "format": "json", "utf8": 1,
        })
        r.raise_for_status()
        hits = r.json().get("query", {}).get("search", [])
        for hit in hits:
            title = hit.get("title")
            page = await _summary(client, title)
            if page:
                results.append(page)

    return {
        "found": len(results) > 0,
        "source": "wikipedia",
        "results": results,
        "disclaimer": "Wikipedia is a tertiary source. Use only as context; verify with primary and peer-reviewed sources.",
    }

async def _summary(client: httpx.AsyncClient, title: str) -> dict | None:
    try:
        r = await client.get(f"{WIKI_API}/page/summary/{quote(title, safe='')}")
        if r.status_code != 200:
            return None
        d = r.json()
        return {
            "title": d.get("title"),
            "extract": (d.get("extract") or "")[:500],
            "url": d.get("content_urls", {}).get("desktop", {}).get("page"),
            "type": d.get("type"),
        }
    except Exception:
        return None
