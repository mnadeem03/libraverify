from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
import os

from backend.database import init_db, settings
from backend.routers import verify, admin, resources, export

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield

app = FastAPI(
    title="LibraVerify",
    description="Open-source citation and claim authenticity checking for libraries",
    version="1.3.0",
    lifespan=lifespan,
)

_raw = [o.strip() for o in settings.allowed_origins.split(",") if o.strip()]
origins = ["*"] if not _raw or "*" in _raw else _raw
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=(origins != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(verify.router)
app.include_router(admin.router)
app.include_router(resources.router)
app.include_router(export.router)

frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend")
static_path = os.path.join(os.path.dirname(__file__), "..", "static")
if os.path.isdir(static_path):
    app.mount("/static", StaticFiles(directory=static_path), name="static")

@app.get("/")
async def serve_frontend():
    index = os.path.join(frontend_path, "index.html")
    if os.path.exists(index):
        return FileResponse(index)
    return {"message": "LibraVerify API is running."}

@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "service": "LibraVerify",
        "version": "1.3.0",
        "library_email": settings.library_email,
        "database": "postgresql" if "postgresql" in settings.database_url else "sqlite",
    }
