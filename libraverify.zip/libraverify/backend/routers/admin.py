from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from backend.database import get_db, settings
from backend.models import AuditLog, LibraryConfig, VerificationJob, OpenSource
from backend.auth import create_access_token, require_admin
from backend.services.source_registry import ensure_builtin_sources
from datetime import timedelta
import re

router = APIRouter(prefix="/api/admin", tags=["Admin"])

DEFAULT_CONFIGS = [
    {"key": "library_email", "value": "", "category": "open_source", "label": "Library contact email (polite pool)", "description": "Used for Crossref, Unpaywall, PubMed identification", "is_secret": False},
    {"key": "openalex_api_key", "value": "", "category": "open_source", "label": "OpenAlex API key", "description": "Free key from openalex.org", "is_secret": True},
    {"key": "semantic_scholar_api_key", "value": "", "category": "open_source", "label": "Semantic Scholar API key", "description": "Optional free tier key", "is_secret": True},
    {"key": "ncbi_api_key", "value": "", "category": "open_source", "label": "NCBI / PubMed API key", "description": "Optional higher rate limits", "is_secret": True},
    {"key": "wos_api_key", "value": "", "category": "subscribed", "label": "Web of Science API key", "description": "If your library subscribes", "is_secret": True},
    {"key": "scopus_api_key", "value": "", "category": "subscribed", "label": "Scopus API key", "description": "Elsevier Scopus", "is_secret": True},
    {"key": "dimensions_api_key", "value": "", "category": "subscribed", "label": "Dimensions API key", "description": "Digital Science", "is_secret": True},
    {"key": "subscribed_notes", "value": "", "category": "subscribed", "label": "Notes on subscribed tools", "description": "GetFTR, LibKey, Cabells, etc.", "is_secret": False},
    {"key": "koha_base_url", "value": "", "category": "ils", "label": "Koha base URL", "description": "e.g. https://koha.yourlibrary.org", "is_secret": False},
    {"key": "koha_api_key", "value": "", "category": "ils", "label": "Koha API token", "description": "Optional", "is_secret": True},
    {"key": "folio_okapi_url", "value": "", "category": "ils", "label": "FOLIO Okapi URL", "description": "", "is_secret": False},
    {"key": "folio_tenant", "value": "", "category": "ils", "label": "FOLIO tenant ID", "description": "", "is_secret": False},
    {"key": "folio_token", "value": "", "category": "ils", "label": "FOLIO token", "description": "", "is_secret": True},
    {"key": "dspace_base_url", "value": "", "category": "ils", "label": "DSpace base URL", "description": "", "is_secret": False},
    {"key": "dspace_api_key", "value": "", "category": "ils", "label": "DSpace API token", "description": "", "is_secret": True},
    {"key": "library_name", "value": "Library", "category": "features", "label": "Library display name", "description": "Shown on PDF reports", "is_secret": False},
    {"key": "enable_factcheck", "value": "true", "category": "features", "label": "Enable fact / claim check", "description": "", "is_secret": False},
    {"key": "enable_ils_search", "value": "true", "category": "features", "label": "Enable Koha / FOLIO / DSpace", "description": "", "is_secret": False},
    {"key": "enable_web_context", "value": "true", "category": "features", "label": "Enable Wikipedia web context", "description": "Tertiary context for claims", "is_secret": False},
]

class LoginRequest(BaseModel):
    username: str
    password: str

class ConfigItem(BaseModel):
    key: str
    value: Optional[str] = ""
    category: Optional[str] = None
    label: Optional[str] = None
    description: Optional[str] = None
    is_secret: Optional[bool] = None

class ConfigBulkUpdate(BaseModel):
    items: List[ConfigItem]

class SourceIn(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    slug: Optional[str] = None
    category: str = "custom"
    base_url: Optional[str] = ""
    docs_url: Optional[str] = ""
    description: Optional[str] = ""
    notes: Optional[str] = ""
    enabled: bool = True
    sort_order: int = 200

class SourceUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    base_url: Optional[str] = None
    docs_url: Optional[str] = None
    description: Optional[str] = None
    notes: Optional[str] = None
    enabled: Optional[bool] = None
    sort_order: Optional[int] = None

def _slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return s[:80] or "source"

async def _ensure_defaults(db: AsyncSession):
    for item in DEFAULT_CONFIGS:
        existing = await db.scalar(select(LibraryConfig).where(LibraryConfig.key == item["key"]))
        if not existing:
            val = item["value"]
            if item["key"] == "library_email" and settings.library_email:
                val = settings.library_email
            db.add(LibraryConfig(**{**item, "value": val}))
    await db.commit()
    await ensure_builtin_sources(db)

@router.post("/login")
async def login(body: LoginRequest):
    if body.username != settings.admin_username or body.password != settings.admin_password:
        raise HTTPException(401, "Invalid credentials")
    token = create_access_token(data={"sub": body.username}, expires_delta=timedelta(hours=8))
    return {"access_token": token, "token_type": "bearer", "username": body.username}

@router.get("/config")
async def get_all_config(category: Optional[str] = None, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    await _ensure_defaults(db)
    q = select(LibraryConfig).order_by(LibraryConfig.category, LibraryConfig.key)
    if category:
        q = q.where(LibraryConfig.category == category)
    rows = (await db.execute(q)).scalars().all()
    return {
        "categories": ["open_source", "subscribed", "ils", "features"],
        "items": [{
            "key": r.key,
            "value": "••••••••" if r.is_secret and r.value else (r.value or ""),
            "raw_set": bool(r.value),
            "category": r.category,
            "label": r.label,
            "description": r.description,
            "is_secret": r.is_secret,
        } for r in rows],
    }

@router.put("/config")
async def update_config(body: ConfigBulkUpdate, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    await _ensure_defaults(db)
    updated = []
    for item in body.items:
        row = await db.scalar(select(LibraryConfig).where(LibraryConfig.key == item.key))
        if not row:
            row = LibraryConfig(key=item.key, category=item.category or "general")
            db.add(row)
        if item.value is not None and item.value != "••••••••":
            row.value = item.value
        if item.label is not None:
            row.label = item.label
        if item.description is not None:
            row.description = item.description
        if item.category is not None:
            row.category = item.category
        updated.append(item.key)
    await db.commit()
    return {"updated": updated, "count": len(updated)}

# ---- Open source databases registry (add / edit / enable) ----

@router.get("/sources")
async def list_sources(db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    await _ensure_defaults(db)
    rows = (await db.execute(select(OpenSource).order_by(OpenSource.sort_order, OpenSource.name))).scalars().all()
    return [_source_dict(r) for r in rows]

@router.post("/sources")
async def create_source(body: SourceIn, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    slug = body.slug or _slugify(body.name)
    exists = await db.scalar(select(OpenSource).where(OpenSource.slug == slug))
    if exists:
        raise HTTPException(400, f"Slug already exists: {slug}")
    row = OpenSource(
        name=body.name, slug=slug, category=body.category,
        base_url=body.base_url or "", docs_url=body.docs_url or "",
        description=body.description or "", notes=body.notes or "",
        enabled=body.enabled, is_builtin=False, sort_order=body.sort_order,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return _source_dict(row)

@router.put("/sources/{source_id}")
async def update_source(source_id: int, body: SourceUpdate, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    row = await db.scalar(select(OpenSource).where(OpenSource.id == source_id))
    if not row:
        raise HTTPException(404, "Source not found")
    for field in ("name", "category", "base_url", "docs_url", "description", "notes", "enabled", "sort_order"):
        val = getattr(body, field)
        if val is not None:
            setattr(row, field, val)
    await db.commit()
    await db.refresh(row)
    return _source_dict(row)

@router.delete("/sources/{source_id}")
async def delete_source(source_id: int, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    row = await db.scalar(select(OpenSource).where(OpenSource.id == source_id))
    if not row:
        raise HTTPException(404, "Source not found")
    if row.is_builtin:
        raise HTTPException(400, "Built-in sources cannot be deleted (disable them instead)")
    await db.delete(row)
    await db.commit()
    return {"deleted": source_id}

def _source_dict(r: OpenSource) -> dict:
    return {
        "id": r.id, "name": r.name, "slug": r.slug, "category": r.category,
        "base_url": r.base_url, "docs_url": r.docs_url, "description": r.description,
        "notes": r.notes, "enabled": r.enabled, "is_builtin": r.is_builtin,
        "sort_order": r.sort_order,
    }

@router.get("/logs")
async def get_logs(limit: int = 50, db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    result = await db.execute(select(AuditLog).order_by(desc(AuditLog.timestamp)).limit(limit))
    logs = result.scalars().all()
    return [{"id": l.id, "timestamp": l.timestamp.isoformat() if l.timestamp else None,
             "action": l.action, "query": (l.query or "")[:200], "result_summary": l.result_summary,
             "user": l.user, "success": l.success} for l in logs]

@router.get("/stats")
async def stats(db: AsyncSession = Depends(get_db), user: str = Depends(require_admin)):
    from sqlalchemy import func
    total = await db.scalar(select(func.count()).select_from(AuditLog)) or 0
    return {"total_verifications": total}
