from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.database import get_db
from backend.models import OpenSource
from backend.services.source_registry import ensure_builtin_sources

router = APIRouter(prefix="/api/resources", tags=["Resources"])

PAID_RESOURCES = [
    {"name": "Web of Science / Clarivate", "category": "Citation Index", "description": "Premium citation database.", "free": False},
    {"name": "Scopus (Elsevier)", "category": "Citation Index", "description": "Abstract and citation database.", "free": False},
    {"name": "Dimensions", "category": "Research Intelligence", "description": "Linked research data platform.", "free": False},
    {"name": "GetFTR / SeamlessAccess", "category": "Access", "description": "Access to subscribed content.", "free": False},
    {"name": "LibKey / BrowZine", "category": "Discovery", "description": "Library linking tools.", "free": False},
    {"name": "Turnitin / iThenticate", "category": "Integrity", "description": "Similarity analysis.", "free": False},
    {"name": "Cabells", "category": "Integrity", "description": "Journalytics and Predatory Reports.", "free": False},
]

@router.get("/free")
async def list_free(db: AsyncSession = Depends(get_db)):
    try:
        await ensure_builtin_sources(db)
        rows = (await db.execute(
            select(OpenSource).where(OpenSource.enabled == True).order_by(OpenSource.sort_order)
        )).scalars().all()
        return [{
            "name": r.name, "category": r.category, "description": r.description or "",
            "url": r.base_url, "docs": r.docs_url, "free": True, "slug": r.slug,
        } for r in rows]
    except Exception:
        return []

@router.get("/paid")
async def list_paid():
    return PAID_RESOURCES

@router.get("/all")
async def list_all(db: AsyncSession = Depends(get_db)):
    free = await list_free(db)
    return {"free": free, "paid": PAID_RESOURCES}
