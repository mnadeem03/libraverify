from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel, Field
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.database import get_db
from backend.models import AuditLog, VerificationJob, LibraryConfig
from backend.services.verifier import verify_single, verify_batch
from backend.services.factcheck import analyze_claim_or_query
from backend.services import openlibrary, ils
from backend.auth import get_current_user
import bibtexparser

router = APIRouter(prefix="/api/verify", tags=["Verification"])

class SingleVerifyRequest(BaseModel):
    doi: Optional[str] = None
    title: Optional[str] = None
    issn: Optional[str] = None

class BatchItem(BaseModel):
    doi: Optional[str] = None
    title: Optional[str] = None
    issn: Optional[str] = None

class BatchVerifyRequest(BaseModel):
    items: List[BatchItem] = Field(..., max_length=50)

class FactCheckRequest(BaseModel):
    text: str = Field(..., min_length=3, max_length=8000)
    mode: str = Field(default="auto")  # auto | citation | fact | book

class BookSearchRequest(BaseModel):
    query: Optional[str] = None
    isbn: Optional[str] = None

class ILSSearchRequest(BaseModel):
    query: str
    systems: List[str] = Field(default=["koha", "folio", "dspace"])

async def _cfg(db: AsyncSession, key: str, default: str = "") -> str:
    row = await db.scalar(select(LibraryConfig).where(LibraryConfig.key == key))
    return (row.value if row and row.value else default) or default

@router.post("/single")
async def verify_citation(body: SingleVerifyRequest, db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    if not any([body.doi, body.title, body.issn]):
        raise HTTPException(400, "Provide at least one of: doi, title, issn")
    report = await verify_single(doi=body.doi, title=body.title, issn=body.issn)
    db.add(AuditLog(action="verify_single", query=str(body.model_dump()), result_summary=report.get("status"),
                    source="multi", user=user or "anonymous", success=report.get("status") != "error",
                    details={"flags": report.get("flags"), "confidence": report.get("confidence")}))
    await db.commit()
    return report

@router.post("/batch")
async def verify_batch_endpoint(body: BatchVerifyRequest, db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    items = [i.model_dump() for i in body.items]
    results = await verify_batch(items)
    job = VerificationJob(status="completed", input_type="list", total_items=len(items), processed=len(results), results=results, user=user or "anonymous")
    db.add(job)
    db.add(AuditLog(action="verify_batch", query=f"{len(items)} items", result_summary=f"completed {len(results)}", user=user or "anonymous", success=True))
    await db.commit()
    return {"job_id": job.id, "results": results}

@router.post("/bibtex")
async def verify_bibtex(file: UploadFile = File(...), db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    if not file.filename.lower().endswith((".bib", ".bibtex")):
        raise HTTPException(400, "Please upload a .bib / .bibtex file")
    content = (await file.read()).decode("utf-8", errors="ignore")
    try:
        dbib = bibtexparser.loads(content)
    except Exception as e:
        raise HTTPException(400, f"Could not parse BibTeX: {e}")
    items = [{"doi": e.get("doi") or e.get("DOI"), "title": e.get("title")} for e in dbib.entries]
    if not items:
        raise HTTPException(400, "No entries found")
    results = await verify_batch(items[:40])
    job = VerificationJob(status="completed", input_type="bibtex", total_items=len(items), processed=len(results), results=results, user=user or "anonymous")
    db.add(job)
    await db.commit()
    return {"job_id": job.id, "total_parsed": len(items), "results": results}

@router.post("/factcheck")
async def factcheck(body: FactCheckRequest, db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    report = await analyze_claim_or_query(body.text, mode=body.mode)
    db.add(AuditLog(action="factcheck", query=body.text[:500], result_summary=report.get("summary", "")[:200],
                    source="factcheck", user=user or "anonymous", success=True, details={"mode": report.get("mode"), "signals": report.get("misinfo_signals")}))
    await db.commit()
    return report

@router.post("/books")
async def search_books(body: BookSearchRequest, db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    if body.isbn:
        result = await openlibrary.lookup_isbn(body.isbn)
        matches = [result] if result.get("found") else []
    elif body.query:
        matches = await openlibrary.search_books(body.query, limit=10)
    else:
        raise HTTPException(400, "Provide query or isbn")
    db.add(AuditLog(action="book_search", query=body.query or body.isbn, result_summary=f"{len(matches)} matches",
                    source="openlibrary", user=user or "anonymous", success=True))
    await db.commit()
    return {"matches": matches, "source": "openlibrary"}

@router.post("/ils")
async def search_ils(body: ILSSearchRequest, db: AsyncSession = Depends(get_db), user: Optional[str] = Depends(get_current_user)):
    out = {}
    if "koha" in body.systems:
        out["koha"] = await ils.search_koha(await _cfg(db, "koha_base_url"), body.query, await _cfg(db, "koha_api_key") or None)
    if "folio" in body.systems:
        out["folio"] = await ils.search_folio(await _cfg(db, "folio_okapi_url"), await _cfg(db, "folio_tenant"), body.query, await _cfg(db, "folio_token") or None)
    if "dspace" in body.systems:
        out["dspace"] = await ils.search_dspace(await _cfg(db, "dspace_base_url"), body.query, await _cfg(db, "dspace_api_key") or None)
    db.add(AuditLog(action="ils_search", query=body.query, result_summary="ils", source="ils", user=user or "anonymous", success=True))
    await db.commit()
    return out
