"""
PDF and CSV report export for patrons / library records.
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, List, Any
from io import BytesIO, StringIO
import csv
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib import colors

router = APIRouter(prefix="/api/export", tags=["Export"])

class ExportRequest(BaseModel):
    report: dict
    library_name: Optional[str] = "Library"
    patron_note: Optional[str] = None

@router.post("/csv")
async def export_csv(body: ExportRequest):
    report = body.report
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(["LibraVerify – Verification Report"])
    writer.writerow(["Generated", datetime.utcnow().isoformat() + "Z"])
    writer.writerow(["Library", body.library_name])
    writer.writerow([])
    writer.writerow(["Field", "Value"])
    writer.writerow(["Status", report.get("status")])
    writer.writerow(["Confidence", report.get("confidence")])
    primary = report.get("primary") or {}
    writer.writerow(["Title", primary.get("title")])
    writer.writerow(["Authors", "; ".join(primary.get("authors") or [])])
    writer.writerow(["Container", primary.get("container_title")])
    writer.writerow(["Year", primary.get("year")])
    writer.writerow(["DOI", primary.get("doi")])
    writer.writerow(["Cited by", primary.get("cited_by")])
    writer.writerow([])
    writer.writerow(["Flags"])
    for f in report.get("flags") or []:
        writer.writerow([f])
    writer.writerow([])
    writer.writerow(["Recommendations"])
    for r in report.get("recommendations") or []:
        writer.writerow([r])
    if body.patron_note:
        writer.writerow([])
        writer.writerow(["Librarian note", body.patron_note])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=libraverify-report.csv"},
    )

@router.post("/pdf")
async def export_pdf(body: ExportRequest):
    report = body.report
    primary = report.get("primary") or {}
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCustom", parent=styles["Heading1"], fontSize=16, spaceAfter=6)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12, spaceBefore=10, spaceAfter=4)
    body_style = styles["Normal"]
    small = ParagraphStyle("Small", parent=styles["Normal"], fontSize=9, textColor=colors.grey)

    story = []
    story.append(Paragraph("LibraVerify – Citation Verification Report", title_style))
    story.append(Paragraph(f"Library: {body.library_name} &nbsp;&nbsp;|&nbsp;&nbsp; Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}", small))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#1e3a8a")))
    story.append(Spacer(1, 8))

    status = (report.get("status") or "unknown").upper()
    conf = report.get("confidence") or "n/a"
    story.append(Paragraph(f"<b>Status:</b> {status} &nbsp;&nbsp; <b>Confidence:</b> {conf}", body_style))
    story.append(Spacer(1, 8))

    story.append(Paragraph("Primary Record", h2))
    story.append(Paragraph(f"<b>Title:</b> {primary.get('title') or '—'}", body_style))
    authors = "; ".join(primary.get("authors") or []) or "—"
    story.append(Paragraph(f"<b>Authors:</b> {authors}", body_style))
    story.append(Paragraph(f"<b>Journal / Container:</b> {primary.get('container_title') or '—'}", body_style))
    story.append(Paragraph(f"<b>Year:</b> {primary.get('year') or '—'} &nbsp;&nbsp; <b>DOI:</b> {primary.get('doi') or '—'}", body_style))
    if primary.get("url") or primary.get("doi"):
        link = primary.get("url") or f"https://doi.org/{primary.get('doi')}"
        story.append(Paragraph(f"<b>Link:</b> {link}", body_style))

    if report.get("open_access"):
        oa = report["open_access"]
        story.append(Paragraph("Open Access", h2))
        if oa.get("is_oa"):
            story.append(Paragraph(f"Yes ({oa.get('status') or ''}) – {oa.get('url') or ''}", body_style))
        else:
            story.append(Paragraph("No legal free version found via Unpaywall", body_style))

    if report.get("retraction"):
        ret = report["retraction"]
        story.append(Paragraph("Retraction / Correction Check", h2))
        if ret.get("is_retracted"):
            story.append(Paragraph("<b>⚠️ RETRACTION SIGNAL</b> – Verify on Retraction Watch before use.", body_style))
        elif ret.get("is_corrected"):
            story.append(Paragraph("A correction/erratum exists. Prefer the updated version.", body_style))
        else:
            story.append(Paragraph("No retraction signal detected in Crossref metadata.", body_style))
        story.append(Paragraph(f"Retraction Watch search: {ret.get('retraction_watch_url')}", small))

    if report.get("predatory"):
        pred = report["predatory"]
        story.append(Paragraph("Journal Quality Heuristics", h2))
        story.append(Paragraph(f"Risk level: <b>{pred.get('risk')}</b>", body_style))
        for f in pred.get("flags") or []:
            story.append(Paragraph(f"• {f}", body_style))
        for n in pred.get("notes") or []:
            story.append(Paragraph(f"• {n}", body_style))

    if report.get("flags"):
        story.append(Paragraph("Flags", h2))
        for f in report["flags"]:
            story.append(Paragraph(f"• {f}", body_style))

    if report.get("recommendations"):
        story.append(Paragraph("Recommendations for Librarian / Patron", h2))
        for r in report["recommendations"]:
            story.append(Paragraph(f"• {r}", body_style))

    if body.patron_note:
        story.append(Paragraph("Librarian Note", h2))
        story.append(Paragraph(body.patron_note, body_style))

    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    story.append(Paragraph(
        "This report was generated by LibraVerify using open scholarly infrastructure "
        "(Crossref, OpenAlex, Unpaywall, Semantic Scholar, PubMed). "
        "It is an assistive tool; final professional judgment rests with the librarian.",
        small,
    ))

    doc.build(story)
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=libraverify-report.pdf"},
    )
