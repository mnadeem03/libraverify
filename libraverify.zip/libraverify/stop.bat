@echo off
title LibraVerify - Stopping...
color 0C
cd /d "%~dp0"

echo.
echo  ============================================
echo     LibraVerify - Stop
echo  ============================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
    echo  Docker was not found. Nothing to stop.
    pause
    exit /b 0
)

echo  Stopping LibraVerify services...
docker compose down
echo.
echo  Done. The application has been stopped.
echo  Your data is kept. Run start.bat anytime to start again.
echo.
pause
