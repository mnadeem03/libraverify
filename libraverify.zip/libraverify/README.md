# LibraVerify

**Open-source citation and claim authenticity checking for libraries**

LibraVerify helps librarians assess the authenticity of citations, DOIs, book details, and free-text queries (including possible AI hallucinations or unsupported claims) by cross-checking **open scholarly and web resources**.

It is an **assistive** tool. Final professional judgment always remains with the librarian.

## What it checks

| Angle | Sources (open) |
|-------|----------------|
| Scholarly metadata & DOIs | Crossref, OpenAlex, Semantic Scholar, PubMed |
| Open access | Unpaywall |
| Books | Open Library |
| Retraction signals | Crossref relations + Retraction Watch link-out |
| Journal quality heuristics | Think.Check.Submit / DOAJ oriented flags |
| Claim / query context | Multi-index search + Wikipedia (tertiary) |
| Local holdings | Optional Koha, FOLIO, DSpace |

Administrators can **enable, disable, edit, and add** open-source databases from the Admin panel.


## Live demo (no download)

Deploy from this GitHub repository so anyone can try LibraVerify in their browser.

**Fastest path:** [Render](https://render.com) free tier + this repo’s `render.yaml`.

Full steps: **[DEPLOY.md](DEPLOY.md)**

After deploy, share your URL (example: `https://libraverify-xxxx.onrender.com`).

## Quick start

### Windows (library staff)

1. Install [Docker Desktop](https://www.docker.com/products/docker-desktop/) and start it.  
2. Double-click **`start.bat`**  
3. Open http://localhost:8000  
4. Stop with **`stop.bat`**

See **START-HERE.txt**.

### Docker (any OS)

```bash
git clone https://github.com/YOUR_ORG/libraverify.git
cd libraverify
cp .env.example .env   # set ADMIN_PASSWORD and LIBRARY_EMAIL
docker compose up --build -d
```

Default admin: `admin` / `admin123` — **change immediately**.

### Local Python (SQLite)

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set DATABASE_URL=sqlite+aiosqlite:///./data/libraverify.db
uvicorn backend.main:app --reload --port 8000
```

## Admin capabilities

- **Open sources** – registry of verification databases (add custom ones, toggle built-ins)
- **API keys** – OpenAlex, Semantic Scholar, NCBI, polite-pool email
- **Subscribed** – optional Web of Science / Scopus / Dimensions keys and notes
- **Koha · FOLIO · DSpace** – base URLs and tokens for local search
- **Features** – library name, feature flags
- **Logs** – recent verification activity

## API overview

| Endpoint | Purpose |
|----------|---------|
| `POST /api/verify/single` | Citation / DOI verification |
| `POST /api/verify/factcheck` | Claim / student query review |
| `POST /api/verify/books` | Book / ISBN (Open Library) |
| `POST /api/verify/ils` | Koha / FOLIO / DSpace |
| `POST /api/verify/batch` | Batch list |
| `POST /api/verify/bibtex` | BibTeX upload |
| `POST /api/export/pdf` · `/csv` | Patron reports |
| `GET/PUT /api/admin/config` | Settings |
| `GET/POST/PUT/DELETE /api/admin/sources` | Open-source registry |

Interactive docs: `/docs`

## Principles

1. Prefer **open infrastructure** (Crossref, OpenAlex, Unpaywall, etc.).  
2. Be **transparent** about limits (especially fact/claim mode and Wikipedia).  
3. Support **library workflows** (export, ILS hooks, audit logs).  
4. Never replace librarian judgment.

## Contributing

Issues and pull requests are welcome. Please keep the focus on open-source verification useful to libraries and avoid proprietary lock-in.

## Licence

MIT — see [LICENSE](LICENSE).
