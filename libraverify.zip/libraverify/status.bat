@echo off
title LibraVerify - Status
cd /d "%~dp0"
echo.
echo  LibraVerify - container status
echo  ----------------------------------
docker compose ps
echo.
echo  Open app:  http://localhost:8000
echo.
pause
