@echo off
title LibraVerify - Starting...
color 0A
cd /d "%~dp0"

echo.
echo  ============================================
echo     LibraVerify - Library Verification
echo  ============================================
echo.

REM Check if Docker is installed
where docker >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Docker was not found on this computer.
    echo.
    echo  Please install Docker Desktop first:
    echo    https://www.docker.com/products/docker-desktop/
    echo.
    echo  After installing, restart your PC, then run this file again.
    echo.
    pause
    exit /b 1
)

REM Check if Docker engine is running
docker info >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Docker Desktop is installed but not running.
    echo.
    echo  Please start Docker Desktop from the Start menu,
    echo  wait until it says "Docker is running", then run this file again.
    echo.
    pause
    exit /b 1
)

REM Create .env from example if missing
if not exist ".env" (
    echo  Creating settings file from template...
    copy ".env.example" ".env" >nul
    echo  Done. You can edit .env later to change the admin password.
    echo.
)

echo  Starting LibraVerify (this may take a minute the first time)...
echo  Please wait while Docker downloads and starts the services.
echo.

docker compose up --build -d
if errorlevel 1 (
    echo.
    echo  [ERROR] Could not start the application.
    echo  Try opening Docker Desktop and running this file again.
    echo.
    pause
    exit /b 1
)

echo.
echo  Waiting for the service to become ready...
timeout /t 8 /nobreak >nul

echo.
echo  ============================================
echo   LibraVerify is running!
echo  ============================================
echo.
echo   Open in your browser:
echo     http://localhost:8000
echo.
echo   Admin login (change after first login):
echo     Username: admin
echo     Password: admin123
echo.
echo   To stop the app later, double-click:  stop.bat
echo.
echo  Opening the app in your default browser...
timeout /t 2 /nobreak >nul
start http://localhost:8000

echo.
echo  You can close this window. The app keeps running in the background.
echo.
pause
