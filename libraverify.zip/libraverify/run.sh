#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if [ ! -d "venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv venv
fi

source venv/bin/activate
pip install -q -r requirements.txt

if [ ! -f ".env" ]; then
  cp .env.example .env
  # Force SQLite for non-Docker local runs
  sed -i 's|^DATABASE_URL=.*|DATABASE_URL=sqlite+aiosqlite:///./data/libraverify.db|' .env 2>/dev/null || true
  echo "Created .env – please edit ADMIN_PASSWORD and LIBRARY_EMAIL"
fi

echo "Starting LibraVerify on http://0.0.0.0:8000 ..."
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
