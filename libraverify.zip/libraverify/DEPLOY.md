# Deploy LibraVerify for a live public demo

Anyone can try the app in a browser **without downloading**, once you deploy from GitHub.

Recommended free option: **[Render](https://render.com)** (connects to GitHub in a few clicks).

---

## Option A — Render (easiest)

### 1. Push this project to GitHub

```bash
# On your computer
unzip libraverify.zip   # or use your local folder
cd libraverify
git init
git add .
git commit -m "LibraVerify: open citation and claim authenticity for libraries"
```

Create a **new public repository** on GitHub (e.g. `libraverify`), then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/libraverify.git
git branch -M main
git push -u origin main
```

### 2. Deploy on Render

1. Sign up at https://render.com (free account; you can use “Sign in with GitHub”).
2. **Dashboard → New → Blueprint**
3. Connect the `libraverify` repository.
4. Render reads `render.yaml` and creates a **free web service**.
5. Click **Apply**.

Wait 3–8 minutes for the first build.

### 3. Open the live URL

Render shows a URL like:

`https://libraverify-xxxx.onrender.com`

Share that link — anyone can test in their browser.

### 4. Admin login on the live demo

In Render → your service → **Environment**:

- `ADMIN_USERNAME` = `admin` (default)
- `ADMIN_PASSWORD` = the generated value (copy it from the dashboard)

Or set your own password there and **Manual Deploy → Deploy latest commit**.

### Notes about the free tier

- The service may **sleep after ~15 minutes** of no traffic; the first request after sleep can take 30–60 seconds.
- Free disk is **ephemeral** (data resets on redeploy). Fine for public trials.
- For a permanent library install, use a paid plan + PostgreSQL, or run Docker on your own server.

---

## Option B — Railway

1. https://railway.app → Login with GitHub  
2. **New Project → Deploy from GitHub repo** → select `libraverify`  
3. Railway uses the `Dockerfile`  
4. Set variables: `SECRET_KEY`, `ADMIN_PASSWORD`, `LIBRARY_EMAIL`, `DATABASE_URL=sqlite+aiosqlite:///./data/libraverify.db`, `ALLOWED_ORIGINS=*`  
5. Generate a public domain under **Settings → Networking**

---

## Option C — Fly.io

```bash
# Install flyctl, then:
fly auth login
fly launch    # uses fly.toml / Dockerfile
fly secrets set ADMIN_PASSWORD=your-secure-password SECRET_KEY=long-random-string
fly apps open
```

---

## After it is live

Add to your GitHub repo **About** section:

- Description: `Open-source citation & claim authenticity checking for libraries`
- Website: your Render/Railway/Fly URL  

Optional badge for README:

```markdown
[![Live demo](https://img.shields.io/badge/Live%20demo-Open-blue)](https://YOUR-APP.onrender.com)
```

---

## Security for a public demo

- Change `ADMIN_PASSWORD` immediately.
- Do not put real institutional API keys on a public demo.
- Mark the site as a **demo / evaluation instance** on the homepage if you customize the UI later.
